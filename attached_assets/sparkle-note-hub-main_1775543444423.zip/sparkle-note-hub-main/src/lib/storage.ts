import { Note } from '@/types/note';
import { v4 } from './uuid';

const STORAGE_KEY = 'keepnotes_data';
const LABELS_KEY = 'keepnotes_labels';

export function generateId(): string {
  return v4();
}

export function loadNotes(): Note[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : getSampleNotes();
  } catch {
    return getSampleNotes();
  }
}

export function saveNotes(notes: Note[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

export function loadLabels(): string[] {
  try {
    const data = localStorage.getItem(LABELS_KEY);
    return data ? JSON.parse(data) : ['Personal', 'Work', 'Ideas', 'Shopping'];
  } catch {
    return ['Personal', 'Work', 'Ideas', 'Shopping'];
  }
}

export function saveLabels(labels: string[]): void {
  localStorage.setItem(LABELS_KEY, JSON.stringify(labels));
}

function getSampleNotes(): Note[] {
  const now = new Date().toISOString();
  return [
    {
      id: generateId(),
      title: 'Welcome to KeepNotes! 📝',
      content: 'This is your personal notes app. Create, organize, and search your notes with ease.',
      color: 'sand',
      labels: ['Personal'],
      isPinned: true,
      isArchived: false,
      isDeleted: false,
      checklist: [],
      createdAt: now,
      updatedAt: now,
    },
    {
      id: generateId(),
      title: 'Project Ideas',
      content: 'Brainstorm new features for the app:\n- Dark mode\n- Collaboration\n- Reminders',
      color: 'mint',
      labels: ['Ideas', 'Work'],
      isPinned: false,
      isArchived: false,
      isDeleted: false,
      checklist: [],
      createdAt: now,
      updatedAt: now,
    },
    {
      id: generateId(),
      title: 'Grocery List',
      content: '',
      color: 'peach',
      labels: ['Shopping'],
      isPinned: false,
      isArchived: false,
      isDeleted: false,
      checklist: [
        { id: generateId(), text: 'Avocados', checked: false },
        { id: generateId(), text: 'Olive oil', checked: true },
        { id: generateId(), text: 'Sourdough bread', checked: false },
        { id: generateId(), text: 'Fresh basil', checked: false },
      ],
      createdAt: now,
      updatedAt: now,
    },
    {
      id: generateId(),
      title: 'Meeting Notes',
      content: 'Discussed Q3 goals. Follow up with the design team about the new dashboard layout.',
      color: 'fog',
      labels: ['Work'],
      isPinned: false,
      isArchived: false,
      isDeleted: false,
      checklist: [],
      createdAt: now,
      updatedAt: now,
    },
    {
      id: generateId(),
      title: 'Book Recommendations',
      content: '• Atomic Habits by James Clear\n• Deep Work by Cal Newport\n• The Design of Everyday Things',
      color: 'dusk',
      labels: ['Personal'],
      isPinned: true,
      isArchived: false,
      isDeleted: false,
      checklist: [],
      createdAt: now,
      updatedAt: now,
    },
    {
      id: generateId(),
      title: 'Workout Plan',
      content: '',
      color: 'coral',
      labels: ['Personal'],
      isPinned: false,
      isArchived: false,
      isDeleted: false,
      checklist: [
        { id: generateId(), text: 'Morning run - 5km', checked: true },
        { id: generateId(), text: 'Push-ups x30', checked: false },
        { id: generateId(), text: 'Plank - 2 min', checked: false },
        { id: generateId(), text: 'Stretching', checked: false },
      ],
      createdAt: now,
      updatedAt: now,
    },
  ];
}
