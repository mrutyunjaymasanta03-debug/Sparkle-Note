import { NoteColor } from '@/types/note';

export const NOTE_COLORS: { value: NoteColor; label: string; className: string }[] = [
  { value: 'default', label: 'Default', className: 'bg-note' },
  { value: 'coral', label: 'Coral', className: 'bg-note-coral' },
  { value: 'peach', label: 'Peach', className: 'bg-note-peach' },
  { value: 'sand', label: 'Sand', className: 'bg-note-sand' },
  { value: 'mint', label: 'Mint', className: 'bg-note-mint' },
  { value: 'sage', label: 'Sage', className: 'bg-note-sage' },
  { value: 'fog', label: 'Fog', className: 'bg-note-fog' },
  { value: 'storm', label: 'Storm', className: 'bg-note-storm' },
  { value: 'dusk', label: 'Dusk', className: 'bg-note-dusk' },
  { value: 'blossom', label: 'Blossom', className: 'bg-note-blossom' },
  { value: 'clay', label: 'Clay', className: 'bg-note-clay' },
  { value: 'chalk', label: 'Chalk', className: 'bg-note-chalk' },
];

export function getNoteColorClass(color: NoteColor): string {
  return NOTE_COLORS.find(c => c.value === color)?.className ?? 'bg-note';
}
