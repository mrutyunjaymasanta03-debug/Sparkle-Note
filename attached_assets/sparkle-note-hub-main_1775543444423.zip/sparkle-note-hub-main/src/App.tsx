import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { NotesProvider } from "@/hooks/useNotes";
import { AppSidebar } from "@/components/AppSidebar";
import NotesPage from "@/pages/NotesPage";
import ArchivePage from "@/pages/ArchivePage";
import TrashPage from "@/pages/TrashPage";
import LabelPage from "@/pages/LabelPage";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <NotesProvider>
          <div className="flex min-h-screen">
            <AppSidebar />
            <main className="flex-1 lg:ml-64 pt-16 lg:pt-0">
              <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
                <Routes>
                  <Route path="/" element={<NotesPage />} />
                  <Route path="/archive" element={<ArchivePage />} />
                  <Route path="/trash" element={<TrashPage />} />
                  <Route path="/label/:label" element={<LabelPage />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </div>
            </main>
          </div>
        </NotesProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
