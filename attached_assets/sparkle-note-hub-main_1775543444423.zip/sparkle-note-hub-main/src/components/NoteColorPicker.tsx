import { useNotes } from '@/hooks/useNotes';
import { Palette } from 'lucide-react';
import { NOTE_COLORS } from '@/lib/noteColors';
import { cn } from '@/lib/utils';
import { useState, useRef, useEffect } from 'react';

export function NoteColorPicker({ noteId }: { noteId: string }) {
  const { setNoteColor, notes } = useNotes();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const note = notes.find(n => n.id === noteId);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
        title="Background color"
      >
        <Palette className="h-4 w-4" />
      </button>
      {open && (
        <div className="absolute bottom-full mb-1 left-0 p-2 bg-popover border border-border rounded-lg shadow-elevated z-50 flex gap-1" onClick={e => e.stopPropagation()}>
          {NOTE_COLORS.map(c => (
            <button
              key={c.value}
              onClick={() => { setNoteColor(noteId, c.value); setOpen(false); }}
              className={cn(
                'h-6 w-6 rounded-full border-2 hover:scale-110 transition-transform',
                c.className,
                note?.color === c.value ? 'border-primary' : 'border-transparent'
              )}
              title={c.label}
            />
          ))}
        </div>
      )}
    </div>
  );
}
