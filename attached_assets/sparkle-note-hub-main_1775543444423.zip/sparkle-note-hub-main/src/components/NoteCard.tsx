import { useState } from 'react';
import { useNotes } from '@/hooks/useNotes';
import { getNoteColorClass } from '@/lib/noteColors';
import { Note } from '@/types/note';
import { Pin, Archive, Trash2, RotateCcw, MoreVertical } from 'lucide-react';
import { NoteColorPicker } from './NoteColorPicker';
import { NoteLabelPicker } from './NoteLabelPicker';
import { NoteEditor } from './NoteEditor';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface NoteCardProps {
  note: Note;
  section: 'notes' | 'archive' | 'trash';
}

export function NoteCard({ note, section }: NoteCardProps) {
  const { togglePin, deleteNote, archiveNote, unarchiveNote, restoreNote, permanentDelete } = useNotes();
  const [isEditing, setIsEditing] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const checkedCount = note.checklist.filter(i => i.checked).length;

  return (
    <>
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={cn(
          'group relative rounded-lg border border-border p-4 cursor-pointer transition-shadow duration-200 note-shadow hover:note-shadow-hover',
          getNoteColorClass(note.color)
        )}
        onClick={() => setIsEditing(true)}
        onMouseEnter={() => setShowActions(true)}
        onMouseLeave={() => setShowActions(false)}
      >
        {/* Pin button */}
        {section === 'notes' && (
          <button
            onClick={(e) => { e.stopPropagation(); togglePin(note.id); }}
            className={cn(
              'absolute top-2 right-2 p-1.5 rounded-full transition-opacity',
              'hover:bg-foreground/10',
              note.isPinned ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
            )}
          >
            <Pin className={cn('h-4 w-4', note.isPinned && 'fill-current')} />
          </button>
        )}

        {/* Title */}
        {note.title && (
          <h3 className="font-medium text-sm mb-1.5 pr-8 line-clamp-2">{note.title}</h3>
        )}

        {/* Content */}
        {note.content && (
          <p className="text-sm text-muted-foreground line-clamp-6 whitespace-pre-wrap">{note.content}</p>
        )}

        {/* Checklist preview */}
        {note.checklist.length > 0 && (
          <div className="mt-2 space-y-1">
            {note.checklist.slice(0, 4).map(item => (
              <div key={item.id} className="flex items-center gap-2 text-sm">
                <div className={cn(
                  'h-3.5 w-3.5 rounded-sm border flex-shrink-0',
                  item.checked ? 'bg-primary border-primary' : 'border-muted-foreground/40'
                )} />
                <span className={cn('truncate', item.checked && 'line-through text-muted-foreground')}>
                  {item.text}
                </span>
              </div>
            ))}
            {note.checklist.length > 4 && (
              <p className="text-xs text-muted-foreground">+{note.checklist.length - 4} more</p>
            )}
            {checkedCount > 0 && (
              <p className="text-xs text-muted-foreground mt-1">{checkedCount}/{note.checklist.length} done</p>
            )}
          </div>
        )}

        {/* Labels */}
        {note.labels.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {note.labels.map(label => (
              <span key={label} className="text-xs px-2 py-0.5 rounded-full bg-foreground/8 text-muted-foreground">
                {label}
              </span>
            ))}
          </div>
        )}

        {/* Action bar */}
        <div className={cn(
          'flex items-center gap-1 mt-3 transition-opacity',
          showActions ? 'opacity-100' : 'opacity-0'
        )}>
          {section === 'notes' && (
            <>
              <NoteColorPicker noteId={note.id} />
              <NoteLabelPicker noteId={note.id} currentLabels={note.labels} />
              <button
                onClick={(e) => { e.stopPropagation(); archiveNote(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
                title="Archive"
              >
                <Archive className="h-4 w-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); deleteNote(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
                title="Delete"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </>
          )}
          {section === 'archive' && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); unarchiveNote(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
                title="Unarchive"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); deleteNote(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
                title="Delete"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </>
          )}
          {section === 'trash' && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); restoreNote(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
                title="Restore"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); permanentDelete(note.id); }}
                className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors text-destructive"
                title="Delete forever"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </>
          )}
        </div>
      </motion.div>

      {isEditing && (
        <NoteEditor note={note} onClose={() => setIsEditing(false)} />
      )}
    </>
  );
}
