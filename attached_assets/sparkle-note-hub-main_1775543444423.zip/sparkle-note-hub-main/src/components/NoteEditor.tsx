import { useState, useRef, useEffect } from 'react';
import { useNotes } from '@/hooks/useNotes';
import { Note, NoteColor } from '@/types/note';
import { getNoteColorClass, NOTE_COLORS } from '@/lib/noteColors';
import { X, Pin, Palette, Tag, Plus, Trash2, CheckSquare } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { generateId } from '@/lib/storage';

interface NoteEditorProps {
  note: Note;
  onClose: () => void;
}

export function NoteEditor({ note, onClose }: NoteEditorProps) {
  const { updateNote, togglePin, setNoteColor, addLabelToNote, removeLabelFromNote,
    toggleChecklistItem, addChecklistItem, removeChecklistItem, labels } = useNotes();
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [showColors, setShowColors] = useState(false);
  const [showLabels, setShowLabels] = useState(false);
  const [newItem, setNewItem] = useState('');
  const titleRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    titleRef.current?.focus();
  }, []);

  const handleClose = () => {
    updateNote(note.id, { title, content });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={handleClose}>
      <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={cn(
          'relative w-full max-w-lg rounded-xl shadow-elevated border border-border overflow-hidden',
          getNoteColorClass(note.color)
        )}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Title */}
        <div className="px-4 pt-4 flex items-center gap-2">
          <input
            ref={titleRef}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title"
            className="flex-1 bg-transparent font-medium text-lg outline-none placeholder:text-muted-foreground/60"
          />
          <button
            onClick={() => togglePin(note.id)}
            className={cn('p-1.5 rounded-full hover:bg-foreground/10', note.isPinned && 'text-primary')}
          >
            <Pin className={cn('h-5 w-5', note.isPinned && 'fill-current')} />
          </button>
        </div>

        {/* Content */}
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Take a note..."
          className="w-full px-4 py-3 bg-transparent outline-none resize-none min-h-[120px] text-sm placeholder:text-muted-foreground/60"
        />

        {/* Checklist */}
        {note.checklist.length > 0 && (
          <div className="px-4 pb-2 space-y-1.5">
            {note.checklist.map(item => (
              <div key={item.id} className="flex items-center gap-2 group/item">
                <button
                  onClick={() => toggleChecklistItem(note.id, item.id)}
                  className={cn(
                    'h-4 w-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors',
                    item.checked ? 'bg-primary border-primary' : 'border-muted-foreground/40 hover:border-primary'
                  )}
                >
                  {item.checked && <CheckSquare className="h-3 w-3 text-primary-foreground" />}
                </button>
                <span className={cn('flex-1 text-sm', item.checked && 'line-through text-muted-foreground')}>
                  {item.text}
                </span>
                <button
                  onClick={() => removeChecklistItem(note.id, item.id)}
                  className="opacity-0 group-hover/item:opacity-100 p-0.5 hover:bg-foreground/10 rounded"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add checklist item */}
        <div className="px-4 pb-2">
          <div className="flex items-center gap-2">
            <Plus className="h-4 w-4 text-muted-foreground" />
            <input
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newItem.trim()) {
                  addChecklistItem(note.id, newItem.trim());
                  setNewItem('');
                }
              }}
              placeholder="Add checklist item"
              className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground/50"
            />
          </div>
        </div>

        {/* Labels */}
        {note.labels.length > 0 && (
          <div className="flex flex-wrap gap-1 px-4 pb-2">
            {note.labels.map(label => (
              <span key={label} className="text-xs px-2 py-0.5 rounded-full bg-foreground/8 text-muted-foreground flex items-center gap-1">
                {label}
                <button onClick={() => removeLabelFromNote(note.id, label)}><X className="h-3 w-3" /></button>
              </span>
            ))}
          </div>
        )}

        {/* Color picker */}
        <AnimatePresence>
          {showColors && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex gap-1.5 px-4 pb-3 flex-wrap">
                {NOTE_COLORS.map(c => (
                  <button
                    key={c.value}
                    onClick={() => setNoteColor(note.id, c.value)}
                    className={cn(
                      'h-7 w-7 rounded-full border-2 transition-transform hover:scale-110',
                      c.className,
                      note.color === c.value ? 'border-primary ring-2 ring-primary/30' : 'border-transparent'
                    )}
                    title={c.label}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Label picker */}
        <AnimatePresence>
          {showLabels && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex gap-1.5 px-4 pb-3 flex-wrap">
                {labels.map(label => (
                  <button
                    key={label}
                    onClick={() => note.labels.includes(label) ? removeLabelFromNote(note.id, label) : addLabelToNote(note.id, label)}
                    className={cn(
                      'text-xs px-3 py-1 rounded-full border transition-colors',
                      note.labels.includes(label)
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-transparent border-border hover:bg-foreground/5'
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
          <div className="flex items-center gap-1">
            <button
              onClick={() => { setShowColors(!showColors); setShowLabels(false); }}
              className={cn('p-2 rounded-full hover:bg-foreground/10', showColors && 'bg-foreground/10')}
            >
              <Palette className="h-4 w-4" />
            </button>
            <button
              onClick={() => { setShowLabels(!showLabels); setShowColors(false); }}
              className={cn('p-2 rounded-full hover:bg-foreground/10', showLabels && 'bg-foreground/10')}
            >
              <Tag className="h-4 w-4" />
            </button>
          </div>
          <button
            onClick={handleClose}
            className="px-4 py-1.5 text-sm font-medium rounded-md hover:bg-foreground/10 transition-colors"
          >
            Close
          </button>
        </div>
      </motion.div>
    </div>
  );
}
