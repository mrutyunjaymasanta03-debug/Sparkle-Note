import { useNotes } from '@/hooks/useNotes';
import { Tag } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState, useRef, useEffect } from 'react';

interface NoteLabelPickerProps {
  noteId: string;
  currentLabels: string[];
}

export function NoteLabelPicker({ noteId, currentLabels }: NoteLabelPickerProps) {
  const { labels, addLabelToNote, removeLabelFromNote } = useNotes();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
        title="Labels"
      >
        <Tag className="h-4 w-4" />
      </button>
      {open && (
        <div className="absolute bottom-full mb-1 left-0 p-2 bg-popover border border-border rounded-lg shadow-elevated z-50 min-w-[140px]" onClick={e => e.stopPropagation()}>
          <p className="text-xs font-medium text-muted-foreground mb-1.5">Labels</p>
          {labels.map(label => (
            <button
              key={label}
              onClick={() => currentLabels.includes(label) ? removeLabelFromNote(noteId, label) : addLabelToNote(noteId, label)}
              className={cn(
                'block w-full text-left text-sm px-2 py-1 rounded hover:bg-foreground/5 transition-colors',
                currentLabels.includes(label) && 'text-primary font-medium'
              )}
            >
              {currentLabels.includes(label) ? '✓ ' : ''}{label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
