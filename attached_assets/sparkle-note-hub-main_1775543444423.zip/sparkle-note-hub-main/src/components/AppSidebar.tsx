import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useNotes } from '@/hooks/useNotes';
import {
  Lightbulb, Archive, Trash2, Tag, Search, Menu, X, Sun, Moon, Plus, Pencil
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function AppSidebar() {
  const location = useLocation();
  const { labels, addLabel, removeLabel, searchQuery, setSearchQuery } = useNotes();
  const [isOpen, setIsOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [editingLabels, setEditingLabels] = useState(false);
  const [newLabel, setNewLabel] = useState('');

  const toggleDark = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  const navItems = [
    { to: '/', icon: Lightbulb, label: 'Notes' },
    { to: '/archive', icon: Archive, label: 'Archive' },
    { to: '/trash', icon: Trash2, label: 'Trash' },
  ];

  return (
    <>
      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 py-3 flex items-center gap-3">
        <button onClick={() => setIsOpen(!isOpen)} className="p-1.5 rounded-lg hover:bg-secondary">
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
        <h1 className="font-display text-xl flex-1">KeepNotes</h1>
        <button onClick={toggleDark} className="p-1.5 rounded-lg hover:bg-secondary">
          {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </button>
      </div>

      {/* Backdrop */}
      {isOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-foreground/20 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={cn(
        'fixed top-0 left-0 h-full z-50 bg-sidebar border-r border-sidebar-border flex flex-col w-64 transition-transform duration-300',
        'lg:translate-x-0 lg:z-30',
        isOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        {/* Header */}
        <div className="px-5 py-5 flex items-center justify-between">
          <h1 className="font-display text-2xl text-sidebar-foreground">KeepNotes</h1>
          <button onClick={toggleDark} className="p-1.5 rounded-lg hover:bg-sidebar-accent text-sidebar-foreground">
            {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>

        {/* Search */}
        <div className="px-3 mb-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-sidebar-accent/60 outline-none placeholder:text-muted-foreground/60 focus:ring-1 focus:ring-sidebar-ring text-sidebar-foreground"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2">
                <X className="h-3.5 w-3.5 text-muted-foreground" />
              </button>
            )}
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-2 space-y-0.5 overflow-y-auto">
          {navItems.map(item => {
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setIsOpen(false)}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground'
                )}
              >
                <item.icon className="h-4.5 w-4.5" />
                {item.label}
              </Link>
            );
          })}

          {/* Labels section */}
          <div className="pt-4 pb-1">
            <div className="flex items-center justify-between px-3 mb-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Labels</p>
              <button onClick={() => setEditingLabels(!editingLabels)} className="p-1 rounded hover:bg-sidebar-accent">
                <Pencil className="h-3 w-3 text-muted-foreground" />
              </button>
            </div>

            {labels.map(label => {
              const isActive = location.pathname === `/label/${encodeURIComponent(label)}`;
              return (
                <div key={label} className="flex items-center">
                  <Link
                    to={`/label/${encodeURIComponent(label)}`}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      'flex-1 flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors',
                      isActive
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium'
                        : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50'
                    )}
                  >
                    <Tag className="h-4 w-4" />
                    {label}
                  </Link>
                  {editingLabels && (
                    <button
                      onClick={() => removeLabel(label)}
                      className="p-1 rounded hover:bg-destructive/10 text-destructive mr-1"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              );
            })}

            {/* Add label */}
            {editingLabels && (
              <div className="flex items-center gap-1 px-3 mt-1">
                <Plus className="h-4 w-4 text-muted-foreground" />
                <input
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newLabel.trim()) {
                      addLabel(newLabel.trim());
                      setNewLabel('');
                    }
                  }}
                  placeholder="New label"
                  className="flex-1 bg-transparent outline-none text-sm py-1.5 placeholder:text-muted-foreground/50 text-sidebar-foreground"
                />
              </div>
            )}
          </div>
        </nav>
      </aside>
    </>
  );
}
