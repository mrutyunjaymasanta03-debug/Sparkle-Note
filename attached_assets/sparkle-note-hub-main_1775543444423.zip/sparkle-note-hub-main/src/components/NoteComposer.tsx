import { useState } from 'react';
import { useNotes } from '@/hooks/useNotes';
import { NOTE_COLORS } from '@/lib/noteColors';
import { NoteColor } from '@/types/note';
import { cn } from '@/lib/utils';
import { Plus, CheckSquare } from 'lucide-react';
import { getNoteColorClass } from '@/lib/noteColors';
import { motion, AnimatePresence } from 'framer-motion';

export function NoteComposer() {
  const { createNote, labels } = useNotes();
  const [isExpanded, setIsExpanded] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState<NoteColor>('default');
  const [selectedLabels, setSelectedLabels] = useState<string[]>([]);
  const [isChecklist, setIsChecklist] = useState(false);
  const [checklistText, setChecklistText] = useState('');

  const handleSubmit = () => {
    if (!title.trim() && !content.trim() && !checklistText.trim()) {
      setIsExpanded(false);
      return;
    }

    const checklist = isChecklist && checklistText.trim()
      ? checklistText.split('\n').filter(l => l.trim()).map(text => ({
          id: crypto.randomUUID?.() || Math.random().toString(36).slice(2),
          text: text.trim(),
          checked: false,
        }))
      : [];

    createNote({
      title,
      content: isChecklist ? '' : content,
      color,
      labels: selectedLabels,
      checklist,
    });

    setTitle('');
    setContent('');
    setColor('default');
    setSelectedLabels([]);
    setIsChecklist(false);
    setChecklistText('');
    setIsExpanded(false);
  };

  if (!isExpanded) {
    return (
      <div
        onClick={() => setIsExpanded(true)}
        className="max-w-xl mx-auto rounded-lg border border-border bg-card note-shadow hover:note-shadow-hover transition-shadow cursor-text px-4 py-3"
      >
        <span className="text-muted-foreground text-sm">Take a note...</span>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'max-w-xl mx-auto rounded-lg border border-border shadow-elevated overflow-hidden',
        getNoteColorClass(color)
      )}
    >
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        className="w-full px-4 pt-3 bg-transparent outline-none font-medium placeholder:text-muted-foreground/60"
      />

      {isChecklist ? (
        <textarea
          value={checklistText}
          onChange={(e) => setChecklistText(e.target.value)}
          placeholder="Enter items, one per line..."
          className="w-full px-4 py-2 bg-transparent outline-none resize-none min-h-[80px] text-sm placeholder:text-muted-foreground/50"
        />
      ) : (
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Take a note..."
          className="w-full px-4 py-2 bg-transparent outline-none resize-none min-h-[80px] text-sm placeholder:text-muted-foreground/50"
        />
      )}

      {/* Color & label pickers */}
      <div className="flex gap-1.5 px-4 pb-2 flex-wrap">
        {NOTE_COLORS.map(c => (
          <button
            key={c.value}
            onClick={() => setColor(c.value)}
            className={cn(
              'h-6 w-6 rounded-full border-2 transition-transform hover:scale-110',
              c.className,
              color === c.value ? 'border-primary' : 'border-transparent'
            )}
            title={c.label}
          />
        ))}
      </div>

      {labels.length > 0 && (
        <div className="flex gap-1.5 px-4 pb-2 flex-wrap">
          {labels.map(label => (
            <button
              key={label}
              onClick={() => setSelectedLabels(prev =>
                prev.includes(label) ? prev.filter(l => l !== label) : [...prev, label]
              )}
              className={cn(
                'text-xs px-2.5 py-0.5 rounded-full border transition-colors',
                selectedLabels.includes(label)
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border hover:bg-foreground/5'
              )}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/50">
        <button
          onClick={() => setIsChecklist(!isChecklist)}
          className={cn('p-1.5 rounded-full hover:bg-foreground/10', isChecklist && 'text-primary bg-foreground/5')}
          title="Checklist"
        >
          <CheckSquare className="h-4 w-4" />
        </button>
        <div className="flex gap-2">
          <button
            onClick={() => { setIsExpanded(false); setTitle(''); setContent(''); setColor('default'); setSelectedLabels([]); setChecklistText(''); }}
            className="px-3 py-1 text-sm rounded-md hover:bg-foreground/10 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-1 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            Save
          </button>
        </div>
      </div>
    </motion.div>
  );
}
