import { Note } from '@/types/note';
import { NoteCard } from './NoteCard';
import { AnimatePresence } from 'framer-motion';

interface NotesGridProps {
  notes: Note[];
  section: 'notes' | 'archive' | 'trash';
  emptyMessage?: string;
  emptyIcon?: React.ReactNode;
}

export function NotesGrid({ notes, section, emptyMessage = 'No notes here', emptyIcon }: NotesGridProps) {
  const pinned = section === 'notes' ? notes.filter(n => n.isPinned) : [];
  const unpinned = section === 'notes' ? notes.filter(n => !n.isPinned) : notes;

  if (notes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        {emptyIcon}
        <p className="mt-3 text-lg">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {pinned.length > 0 && (
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 px-1">Pinned</p>
          <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-3 space-y-3">
            <AnimatePresence>
              {pinned.map(note => (
                <div key={note.id} className="break-inside-avoid">
                  <NoteCard note={note} section={section} />
                </div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      {pinned.length > 0 && unpinned.length > 0 && (
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1">Others</p>
      )}

      {unpinned.length > 0 && (
        <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-3 space-y-3">
          <AnimatePresence>
            {unpinned.map(note => (
              <div key={note.id} className="break-inside-avoid">
                <NoteCard note={note} section={section} />
              </div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
