import { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { Note, NoteColor, ChecklistItem } from '@/types/note';
import { loadNotes, saveNotes, loadLabels, saveLabels, generateId } from '@/lib/storage';

interface NotesContextType {
  notes: Note[];
  labels: string[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  createNote: (data: Partial<Note>) => Note;
  updateNote: (id: string, data: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  permanentDelete: (id: string) => void;
  restoreNote: (id: string) => void;
  archiveNote: (id: string) => void;
  unarchiveNote: (id: string) => void;
  togglePin: (id: string) => void;
  setNoteColor: (id: string, color: NoteColor) => void;
  addLabel: (label: string) => void;
  removeLabel: (label: string) => void;
  addLabelToNote: (noteId: string, label: string) => void;
  removeLabelFromNote: (noteId: string, label: string) => void;
  emptyTrash: () => void;
  toggleChecklistItem: (noteId: string, itemId: string) => void;
  addChecklistItem: (noteId: string, text: string) => void;
  removeChecklistItem: (noteId: string, itemId: string) => void;
  getFilteredNotes: (section: 'notes' | 'archive' | 'trash', labelFilter?: string) => Note[];
}

const NotesContext = createContext<NotesContextType | undefined>(undefined);

export function NotesProvider({ children }: { children: ReactNode }) {
  const [notes, setNotes] = useState<Note[]>(() => loadNotes());
  const [labels, setLabels] = useState<string[]>(() => loadLabels());
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => { saveNotes(notes); }, [notes]);
  useEffect(() => { saveLabels(labels); }, [labels]);

  const update = useCallback((id: string, data: Partial<Note>) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, ...data, updatedAt: new Date().toISOString() } : n));
  }, []);

  const createNote = useCallback((data: Partial<Note>) => {
    const now = new Date().toISOString();
    const note: Note = {
      id: generateId(),
      title: '',
      content: '',
      color: 'default',
      labels: [],
      isPinned: false,
      isArchived: false,
      isDeleted: false,
      checklist: [],
      createdAt: now,
      updatedAt: now,
      ...data,
    };
    setNotes(prev => [note, ...prev]);
    return note;
  }, []);

  const deleteNote = useCallback((id: string) => update(id, { isDeleted: true, isPinned: false }), [update]);
  const permanentDelete = useCallback((id: string) => setNotes(prev => prev.filter(n => n.id !== id)), []);
  const restoreNote = useCallback((id: string) => update(id, { isDeleted: false }), [update]);
  const archiveNote = useCallback((id: string) => update(id, { isArchived: true, isPinned: false }), [update]);
  const unarchiveNote = useCallback((id: string) => update(id, { isArchived: false }), [update]);
  const togglePin = useCallback((id: string) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, isPinned: !n.isPinned, updatedAt: new Date().toISOString() } : n));
  }, []);
  const setNoteColor = useCallback((id: string, color: NoteColor) => update(id, { color }), [update]);

  const addLabel = useCallback((label: string) => {
    setLabels(prev => prev.includes(label) ? prev : [...prev, label]);
  }, []);
  const removeLabel = useCallback((label: string) => {
    setLabels(prev => prev.filter(l => l !== label));
    setNotes(prev => prev.map(n => ({ ...n, labels: n.labels.filter(l => l !== label) })));
  }, []);
  const addLabelToNote = useCallback((noteId: string, label: string) => {
    setNotes(prev => prev.map(n => n.id === noteId && !n.labels.includes(label)
      ? { ...n, labels: [...n.labels, label], updatedAt: new Date().toISOString() } : n));
  }, []);
  const removeLabelFromNote = useCallback((noteId: string, label: string) => {
    setNotes(prev => prev.map(n => n.id === noteId
      ? { ...n, labels: n.labels.filter(l => l !== label), updatedAt: new Date().toISOString() } : n));
  }, []);

  const emptyTrash = useCallback(() => setNotes(prev => prev.filter(n => !n.isDeleted)), []);

  const toggleChecklistItem = useCallback((noteId: string, itemId: string) => {
    setNotes(prev => prev.map(n => n.id === noteId ? {
      ...n,
      checklist: n.checklist.map(i => i.id === itemId ? { ...i, checked: !i.checked } : i),
      updatedAt: new Date().toISOString(),
    } : n));
  }, []);

  const addChecklistItem = useCallback((noteId: string, text: string) => {
    const item: ChecklistItem = { id: generateId(), text, checked: false };
    setNotes(prev => prev.map(n => n.id === noteId ? {
      ...n, checklist: [...n.checklist, item], updatedAt: new Date().toISOString(),
    } : n));
  }, []);

  const removeChecklistItem = useCallback((noteId: string, itemId: string) => {
    setNotes(prev => prev.map(n => n.id === noteId ? {
      ...n, checklist: n.checklist.filter(i => i.id !== itemId), updatedAt: new Date().toISOString(),
    } : n));
  }, []);

  const getFilteredNotes = useCallback((section: 'notes' | 'archive' | 'trash', labelFilter?: string) => {
    let filtered = notes;
    if (section === 'notes') filtered = filtered.filter(n => !n.isArchived && !n.isDeleted);
    else if (section === 'archive') filtered = filtered.filter(n => n.isArchived && !n.isDeleted);
    else if (section === 'trash') filtered = filtered.filter(n => n.isDeleted);

    if (labelFilter) filtered = filtered.filter(n => n.labels.includes(labelFilter));

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(n =>
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        n.labels.some(l => l.toLowerCase().includes(q)) ||
        n.checklist.some(i => i.text.toLowerCase().includes(q))
      );
    }

    return filtered;
  }, [notes, searchQuery]);

  return (
    <NotesContext.Provider value={{
      notes, labels, searchQuery, setSearchQuery,
      createNote, updateNote: update, deleteNote, permanentDelete, restoreNote,
      archiveNote, unarchiveNote, togglePin, setNoteColor,
      addLabel, removeLabel, addLabelToNote, removeLabelFromNote,
      emptyTrash, toggleChecklistItem, addChecklistItem, removeChecklistItem,
      getFilteredNotes,
    }}>
      {children}
    </NotesContext.Provider>
  );
}

export function useNotes() {
  const ctx = useContext(NotesContext);
  if (!ctx) throw new Error('useNotes must be used within NotesProvider');
  return ctx;
}
