export type NoteColor =
  | 'default' | 'coral' | 'peach' | 'sand' | 'mint'
  | 'sage' | 'fog' | 'storm' | 'dusk' | 'blossom' | 'clay' | 'chalk';

export interface ChecklistItem {
  id: string;
  text: string;
  checked: boolean;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  color: NoteColor;
  labels: string[];
  isPinned: boolean;
  isArchived: boolean;
  isDeleted: boolean;
  checklist: ChecklistItem[];
  createdAt: string;
  updatedAt: string;
}

export type NoteView = 'grid' | 'list';

export type AppSection = 'notes' | 'archive' | 'trash' | 'label';
