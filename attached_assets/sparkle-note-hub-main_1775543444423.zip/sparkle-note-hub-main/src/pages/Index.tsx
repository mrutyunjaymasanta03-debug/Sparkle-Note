import NotesPage from "./NotesPage";

export default function Index() {
  return <NotesPage />;
}
