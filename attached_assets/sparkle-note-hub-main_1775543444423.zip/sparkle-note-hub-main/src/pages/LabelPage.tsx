import { useParams } from 'react-router-dom';
import { useNotes } from '@/hooks/useNotes';
import { NoteComposer } from '@/components/NoteComposer';
import { NotesGrid } from '@/components/NotesGrid';
import { Tag } from 'lucide-react';

export default function LabelPage() {
  const { label } = useParams<{ label: string }>();
  const decodedLabel = decodeURIComponent(label || '');
  const { getFilteredNotes } = useNotes();
  const notes = getFilteredNotes('notes', decodedLabel);

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl flex items-center gap-2">
        <Tag className="h-6 w-6" />
        {decodedLabel}
      </h2>
      <NoteComposer />
      <NotesGrid
        notes={notes}
        section="notes"
        emptyMessage={`No notes with label "${decodedLabel}"`}
        emptyIcon={<Tag className="h-16 w-16 text-muted-foreground/30" />}
      />
    </div>
  );
}
