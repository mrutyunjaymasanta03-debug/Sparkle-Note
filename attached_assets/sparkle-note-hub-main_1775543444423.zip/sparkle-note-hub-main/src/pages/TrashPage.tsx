import { useNotes } from '@/hooks/useNotes';
import { NotesGrid } from '@/components/NotesGrid';
import { Trash2 } from 'lucide-react';

export default function TrashPage() {
  const { getFilteredNotes, emptyTrash } = useNotes();
  const notes = getFilteredNotes('trash');

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl">Trash</h2>
        {notes.length > 0 && (
          <button
            onClick={emptyTrash}
            className="text-sm px-3 py-1.5 rounded-md text-destructive hover:bg-destructive/10 transition-colors font-medium"
          >
            Empty trash
          </button>
        )}
      </div>
      <NotesGrid
        notes={notes}
        section="trash"
        emptyMessage="Trash is empty"
        emptyIcon={<Trash2 className="h-16 w-16 text-muted-foreground/30" />}
      />
    </div>
  );
}
