import { useNotes } from '@/hooks/useNotes';
import { NoteComposer } from '@/components/NoteComposer';
import { NotesGrid } from '@/components/NotesGrid';
import { Lightbulb } from 'lucide-react';

export default function NotesPage() {
  const { getFilteredNotes } = useNotes();
  const notes = getFilteredNotes('notes');

  return (
    <div className="space-y-6">
      <NoteComposer />
      <NotesGrid
        notes={notes}
        section="notes"
        emptyMessage="Your notes will appear here"
        emptyIcon={<Lightbulb className="h-16 w-16 text-muted-foreground/30" />}
      />
    </div>
  );
}
