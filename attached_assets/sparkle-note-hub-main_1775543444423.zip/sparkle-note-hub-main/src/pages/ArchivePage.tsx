import { useNotes } from '@/hooks/useNotes';
import { NotesGrid } from '@/components/NotesGrid';
import { Archive } from 'lucide-react';

export default function ArchivePage() {
  const { getFilteredNotes } = useNotes();
  const notes = getFilteredNotes('archive');

  return (
    <div>
      <h2 className="font-display text-2xl mb-6">Archive</h2>
      <NotesGrid
        notes={notes}
        section="archive"
        emptyMessage="No archived notes"
        emptyIcon={<Archive className="h-16 w-16 text-muted-foreground/30" />}
      />
    </div>
  );
}
